import { Button, FormControl, FormLabel, Input, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, useToast } from '@chakra-ui/react'
import React, { useContext, useEffect, useState } from 'react'
import MainContext from '../../store/context'
import axios from 'axios'

const CategoryUpdateAlert = ({ isOpen, onOpen, onClose, updateItemId }) => {
    const { state } = useContext(MainContext)
    const toast = useToast()
    const URL = 'http://localhost:3000/categories'
    const [newTitle, setNewTitle] = useState('')
    const [newImageURL, setNewImageURL] = useState('')

    useEffect(() => {
        setNewImageURL(`${state.categories?.find(item => item.id == updateItemId)?.image}`)
        setNewTitle(`${state.categories?.find(item => item.id == updateItemId)?.title}`)
    }, [updateItemId])

    async function updateCategory(id) {
        const data = { newTitle, newImageURL };
        await axios.patch(`${URL}/${id}`, data)
            .then((res) => {
                toast({ title: 'Category success updated', status: 'success', duration: 1000, isClosable: true, position: 'bottom-right' })
            })
            .catch((err) => {
                toast({ title: 'ERROR', status: 'error', duration: 1000, isClosable: true, position: 'bottom-right' })
            })
    }


    return (
        <div>
            <Modal isOpen={isOpen} onClose={onClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Updating</ModalHeader>
                    <ModalCloseButton />
                        <ModalBody pb={6}>
                            <FormControl>
                                <FormLabel>Image URL</FormLabel>
                                <Input value={newImageURL} onChange={(e) => setNewImageURL(e.target.value)} placeholder='image url...' />
                            </FormControl>

                            <FormControl mt={4}>
                                <FormLabel>Title</FormLabel>
                                <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder='category name...' />
                            </FormControl>
                        </ModalBody>

                        <ModalFooter>
                            <Button colorScheme='blue' mr={3} onClick={() => updateCategory(updateItemId)}>
                                Save
                            </Button>
                            <Button onClick={() =>onClose()}>Cancel</Button>
                        </ModalFooter>
                </ModalContent>
            </Modal>
        </div>
    )
}

export default CategoryUpdateAlert