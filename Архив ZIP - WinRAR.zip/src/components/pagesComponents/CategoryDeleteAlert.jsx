import { AlertDialog, AlertDialogBody, AlertDialogContent, AlertDialogFooter, AlertDialogHeader, AlertDialogOverlay, Button, useToast } from '@chakra-ui/react'
import React, { useContext } from 'react'
import { getCategories, getProducts } from '../../hooks/getDataAxios';
import MainContext from '../../store/context';
import axios from 'axios';
const CategoryDeleteAlert = ({ isOpen, onOpen, onClose, deletedItemId }) => {
    const toast = useToast()
    const { state, dispatch } = useContext(MainContext)
    const categoryURL = 'http://localhost:3000/categories'
    const productsURL = 'http://localhost:3000/products'





    async function deleteCategory(id) {
        await axios.delete(categoryURL + '/' + id)
            .then((res) => {
                toast({ title: 'Category success deleted', status: 'success', duration: 1000, isClosable: true, position: 'bottom-right' })
            })
            .catch((err) => {
                toast({ title: 'ERROR', status: 'error', duration: 1000, isClosable: true, position: 'bottom-right' })
            })
        await axios.delete(categoryURL + '/' + id + '?_dependent=products')
            .then((res) => {
                console.log(res)
            })
            .catch((err) => {
                console.log(err)
            })
        getCategories(categoryURL, dispatch)
        onClose()
    }

    return (
        <>
            <AlertDialog isOpen={isOpen} onClose={onClose} >
                <AlertDialogOverlay>
                    <AlertDialogContent>
                        <AlertDialogHeader fontSize='lg' fontWeight='bold'>Delete Customer</AlertDialogHeader>
                        <AlertDialogBody>Are you sure? You can't undo this action afterwards.</AlertDialogBody>
                        <AlertDialogFooter>
                            <Button onClick={onClose}>Cancel</Button>
                            <Button colorScheme='red' onClick={() => deleteCategory(deletedItemId)} ml={3}>Delete</Button>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialogOverlay>
            </AlertDialog>
        </>
    )
}

export default CategoryDeleteAlert