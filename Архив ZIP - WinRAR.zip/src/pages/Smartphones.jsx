import { Box, Text } from '@chakra-ui/react'
import React from 'react'

const Smartphones = () => {
  return (
    <Box>
        <Text>Category - 1</Text>
    </Box>
  )
}

export default Smartphones