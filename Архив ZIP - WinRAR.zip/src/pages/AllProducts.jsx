import { Box, Card, CardBody, Grid, GridItem, Image, Skeleton, Stack, Text, useDisclosure } from '@chakra-ui/react'
import React, { useContext, useEffect, useState } from 'react'
import { getCategories, getProducts } from '../hooks/getDataAxios'
import MainContext from '../store/context'
import ProductItem from '../components/pagesComponents/ProductItem'
import ProductDeleteAlert from '../components/pagesComponents/ProductDeleteAlert'

const AllProducts = () => {
  const { state, dispatch } = useContext(MainContext)
  const URL1 = 'http://localhost:3000/products'
  const URL2 = 'http://localhost:3000/categories'
  const itemsForSkeleton = [1, 2, 3, 4, 5]
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [deletedItemId, setDeletedItemID] = useState()
  useEffect(() => { getProducts(URL1, dispatch) }, [])
  useEffect(() => { getCategories(URL2, dispatch) }, [])

  function deleteFunc(id) {
    onOpen()
    setDeletedItemID(id)
  }

  return (
    <Box padding={'20px'}>
      {state.isProductsLoading && state.products.length === 0 ?
        <Grid gap={'10px'} rowGap={"30px"} gridTemplateColumns={{ sm: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}>
          {itemsForSkeleton.map(item =>
          (<Card key={item}>
            <CardBody>
              <Stack display={'flex'} flexDir={'column'} key={item}>
                <Box width={'100%'}>
                  <Skeleton height={'100px'} width={'full'} />
                </Box>
                <Box display={'flex'} flexDir={'column'} gap={'10px'} width={'100%'}>
                  <Skeleton height='20px' />
                  <Skeleton height='20px' />
                  <Box display={'flex'} width={'full'} gap={'10px'}>
                    <Skeleton height='20px' width={'50%'} />
                    <Skeleton height='20px' width={'50%'} />
                  </Box>
                </Box>
              </Stack>
            </CardBody>
          </Card>
          ))}
        </Grid> :
        <>
          <ProductDeleteAlert onOpen={onOpen} onClose={onClose} isOpen={isOpen} deletedItemId={deletedItemId}/>
          <Grid gap={'10px'} rowGap={"30px"} gridTemplateColumns={{ sm: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }}>
            {state.products.map(item => (
              <GridItem key={item.id}>
                <ProductItem item={item} deleteFunc={deleteFunc} />
              </GridItem>
            ))}
          </Grid>
        </>
      }
    </Box>
  )
}

export default AllProducts