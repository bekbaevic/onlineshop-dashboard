import { Box, Text } from '@chakra-ui/react'
import React from 'react'

const Laptops = () => {
  return (
    <Box>
        <Text>Category - 3</Text>
    </Box>
  )
}

export default Laptops