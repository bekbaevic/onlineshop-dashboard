import { Box, Text } from '@chakra-ui/react'
import React from 'react'

const Books = () => {
  return (
    <Box>
        <Text>Category - 2</Text>
    </Box>
  )
}

export default Books